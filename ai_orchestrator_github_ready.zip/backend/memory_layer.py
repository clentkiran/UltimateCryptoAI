import chromadb
from chromadb.utils import embedding_functions

class MemoryLayer:
    def __init__(self, collection_name="ai_orchestrator"):
        self.client = chromadb.PersistentClient(path="./chroma_db")
        self.collection = self.client.get_or_create_collection(name=collection_name)
        self.embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )

    def store_text(self, text):
        try:
            embedding = self.embedding_fn([text])[0]
            self.collection.add(ids=[str(hash(text))], embeddings=[embedding], documents=[text])
            return {"message": "Text stored successfully"}
        except Exception as e:
            return {"error": str(e)}

    def query_text(self, query, n_results=5):
        try:
            query_embedding = self.embedding_fn([query])[0]
            results = self.collection.query(query_embeddings=[query_embedding], n_results=n_results)
            return {"results": results["documents"]}
        except Exception as e:
            return {"error": str(e)}
