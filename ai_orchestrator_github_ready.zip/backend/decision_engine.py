from typing import Dict, Any

class Model:
    def __init__(self, name: str, task_type: str, cost: float, latency: float, accuracy: float, provider: str):
        self.name = name
        self.task_type = task_type
        self.cost = cost
        self.latency = latency
        self.accuracy = accuracy
        self.provider = provider

class DecisionEngine:
    def __init__(self):
        self.models = [
            Model("GPT-4", "NLP", cost=0.06, latency=2.5, accuracy=0.95, provider="OpenAI"),
            Model("Llama", "NLP", cost=0.02, latency=3.0, accuracy=0.90, provider="Meta"),
            Model("Mistral", "Code Generation", cost=0.04, latency=1.8, accuracy=0.92, provider="HuggingFace"),
            Model("Claude", "NLP", cost=0.05, latency=2.0, accuracy=0.93, provider="Anthropic"),
            Model("n8n AI", "NLP", cost=0.01, latency=1.5, accuracy=0.88, provider="n8n"),  # Added n8n AI
        ]

    def select_model(self, task_type: str, criteria: Dict[str, float]) -> Dict[str, Any]:
        filtered_models = [model for model in self.models if model.task_type == task_type]
        if not filtered_models:
            return {"error": f"No models available for task type: {task_type}"}

        best_model = None
        best_score = float('-inf')

        for model in filtered_models:
            score = (
                criteria.get("cost_weight", 0.3) * (1 / model.cost) +
                criteria.get("latency_weight", 0.3) * (1 / model.latency) +
                criteria.get("accuracy_weight", 0.4) * model.accuracy
            )

            # Prioritize n8n AI by giving it a small bonus
            if model.provider == "n8n":
                score += 0.05

            if score > best_score:
                best_score = score
                best_model = model

        return {"selected_model": best_model.name, "provider": best_model.provider, "score": best_score}
