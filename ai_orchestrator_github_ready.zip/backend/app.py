from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from memory_layer import MemoryLayer
from decision_engine import DecisionEngine
import requests
import os

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
memory_layer = MemoryLayer()
decision_engine = DecisionEngine()

class TextInput(BaseModel):
    text: str

class QueryInput(BaseModel):
    query: str
    n_results: int = 5

class TaskInput(BaseModel):
    task_type: str
    criteria: dict

class AIWorkflowInput(BaseModel):
    model_name: str  # Specify which AI model to use
    provider: str  # AI provider (OpenAI, Hugging Face, Meta, etc.)
    input_text: str  # Input text to process

@app.post("/store/")
async def store_text(input_data: TextInput):
    result = memory_layer.store_text(input_data.text)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result

@app.post("/query/")
async def query_text(input_data: QueryInput):
    result = memory_layer.query_text(input_data.query, input_data.n_results)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result

@app.post("/select-model/")
async def select_model(input_data: TaskInput):
    result = decision_engine.select_model(input_data.task_type, input_data.criteria)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result

@app.post("/execute-ai-workflow/")
async def execute_ai_workflow(input_data: AIWorkflowInput):
    api_endpoints = {
        "OpenAI": os.getenv("OPENAI_API_URL", "https://api.openai.com/v1/completions"),
        "HuggingFace": os.getenv("HUGGINGFACE_API_URL", "https://api-inference.huggingface.co/models"),
        "Meta": os.getenv("META_API_URL", "https://meta.ai/api"),  # Example placeholder
    }

    if input_data.provider not in api_endpoints:
        raise HTTPException(status_code=400, detail="Unsupported AI provider")

    headers = {"Authorization": f"Bearer {os.getenv('API_KEY', 'your-api-key')}"}
    payload = {"model": input_data.model_name, "input": input_data.input_text}

    try:
        response = requests.post(api_endpoints[input_data.provider], headers=headers, json=payload)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
